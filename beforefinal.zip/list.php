<?php
	include ('head.php');
?>		
<div id="bla"><br/><br/><br/></div><br/>
		<h1 style="margin-left: 5%">Showing By : Action</h1>
		<br/>
		<div style="width: 90%; margin: 0 auto; background; color:; border: ; padding:20px">
		<table cellspacing="10" width="100%">
              <tr>
			  <td width="30%">
					<img  src="un1.jpg" width="100%"/>
				</td>
              	<td width="20%" style="border-left: 1px solid black">
              	<div id="ll">
                        <ul id="lll">
                        	<li><h1>Uncharted 4</h1></li>
                        	<li><h2>Release Date : May 10, 2016</h2></li>
                        	<li><h2>Platform : PS4</h2></li>
                        	<li><h2>Developer : Naughty Dog</h2></li>
                        	<li><h2>Publisher : Sony</h2></li>
                        	<li><h2>Genre : Action,Adventure</h2></li>
                        	<li><h2>Theme : Action</h2></li>
                        </ul>
                </div>
				</td>
				<td width="10%">
					<h3 style=" color:red">Review : 10</h1>
					<h3 style="color:blue">User Avg : 10</h1>
				</td>
				              <td>
					<iframe width="520" height="280" style="margin-left: 10%"
                src="https://www.youtube.com/embed/d5nfXqffvyc">
                </iframe>
			  </td>
				</tr>
		</table>
		<hr/>
		</div>
<?php
	include ('foot.php');
?>