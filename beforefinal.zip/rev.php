<?php
	include ('head.php');
?>
	
            <!_____after menu__>
			<div id="bla"><br/><br/><br/></div>
      <div id="rev" style="background-image:url(uuu.jpg)">
              <table  cellspacing="5" width="100%">
              
<!______________query_______________>
                <?php
                  $game_id=$_GET['game_name']

                  $game = $db->query("SELECT * 
                                  FROM game_main
                                  WHERE id = $game_id");
                  $row = $game->fetch_assoc();
                  while($row!=NULL){
                    echo"
                      <li>$row[title]<br>
                          Coming $row[year] 
                      </li><br>
                    ";
                    $row = $game->fetch_assoc();
                  }
                ?>
                <!_____________query not done_______________>



              <tr>
			            <td width="10%">
					           <img id="ki" src="unc.jpg" width="100%"/>
				          </td>
                  <td width="50%">
                    <ul id="name">
                      <li><h1 style="color: white">Uncharted 4</h1></li>
                      <li><h2 style="color: white">Released : May 10, 2016</h2></li>
                      <li><h2 style="color: white">PS4(59.99$)</h2></li>
                    </ul>
			            </td>
                  <td id="sc" width="10%">
                  <div id="score" background="black">
                     <h4 style="color: white">GameGEN</h4>
                     <h1 style="color: white">&nbsp;&nbsp;10</h1>
                     <h3 style="color: white">Essential</h3>
                  </div>
                  </td>
                   <td width="10%">
                   <div id="score">
                     <h4 style="color: white">User Avg</h4>
                     <h1 style="color: white">&nbsp;&nbsp;10</h1>
                    </div>
                  </td>
              </tr>
              </table>
              </div>
              <div style="text-align: ;">
              <div style="width: 1000px; margin: 0 auto; background; color:; border: ; padding:20px" >
              <br/>
                <h3 style="color: blue">REVIEWED ON PS4 / 10 MAY 2016</h3>
                <h1 style="color: red"> UNCHARTED 4: A THIEF'S END REVIEW</h1>
                <h4 style="color: blue"><Strong style="color: black">Share.</Strong> A remarkable achievement in blockbuster storytelling and graphical beauty, only let down by an overly long third act.</h4>
                <hr/>
                <br/><br/>
                <p><strong style="color: blue">By Toha</strong> --> Its 15-hour experience kicks off with focus. Uncharted 4’s story is established in a compelling handful of chapters that weave their way through different time periods with tightly directed cinematic flair. While its setup is overly familiar - Nathan Drake and Elena Fisher are attempting to retire from action-heroism and live a normal life until Nate’s presumed-dead brother turns up with an offer he can’t refuse - a strong emotional throughline is born from the characters’ struggle to reconcile their adult responsibilities with the promise of excitement they secretly crave. Uncharted 4 does a terrific job of exploring a more world-weary group of adventurers, with their concerns and musings layered throughout its quieter moments.</p><br/>

                <p>These incidental conversations are a marvel. It’s here that we see characters bristle and soften, brought slowly to life with considered writing and a peerless voice cast. Performances from series veterans Nolan North (Nathan Drake), Emily Rose (Elena Fisher), and Richard McGonagle (Victor Sullivan) are as big-hearted as ever, while newcomers Troy Baker (Samuel Drake), Laura Bailey (Nadine Ross), and Warren Kole (Rafe Adler) are nicely understated in more enigmatic roles.</p><br/>

                <p>Uncharted 4’s companion characters never break the spell in more frantic or tense sections, either. If you choose to play stealthily, they’ll crouch down in the long grass beside you (and unlike Ellie in The Last of Us, they do an excellent job of staying out of enemy sightlines). If they’re in your way while climbing, they’ll let you clamber over them. They’re competent in gun fights, helpful in traversal, and typically witty throughout. They feel vital.</p><br/>

                <iframe width="720" height="400"
                src="https://www.youtube.com/embed/d5nfXqffvyc?autoplay=1">
                </iframe>
                <br/><br/><br/>
                <p>Uncharted 4’s companion characters never break the spell in more frantic or tense sections, either. If you choose to play stealthily, they’ll crouch down in the long grass beside you (and unlike Ellie in The Last of Us, they do an excellent job of staying out of enemy sightlines). If they’re in your way while climbing, they’ll let you clamber over them. They’re competent in gun fights, helpful in traversal, and typically witty throughout. They feel vital.</p><br/>

                <p>Uncharted 4’s companion characters never break the spell in more frantic or tense sections, either. If you choose to play stealthily, they’ll crouch down in the long grass beside you (and unlike Ellie in The Last of Us, they do an excellent job of staying out of enemy sightlines). If they’re in your way while climbing, they’ll let you clamber over them. They’re competent in gun fights, helpful in traversal, and typically witty throughout. They feel vital.</p><br/>
              </div>
              </div>

            <!_____________________>
<?php
	include ('foot.php');
?>

