<br><br><br><br>
           <div id="end">
		   <table width="100%" cellspacing="30">
				<tr>
					<td colspan="5"  style="color: white">© 2016 CBS Interactive Inc.All rights reserved.
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					Privacy Policy&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ad Choice
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Terms of Use
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;HelpAdvertiseCareers

					</td>
				</tr>
				<tr>
					<td>
					<div id="last_list1">
						<h2  style="color: white">USEFUL SITES :</h2>
						<ul>
							<li><a href="http://www.ign.com/">IGN</a></li>
							<li><a href="http://www.gamesradar.com">GAMESRADAR</a></li>
							<li><a href="http://www.gamersyde.com">GAMERSYDE</a></li>
							<li><a href="http://www.gamespot.com">GAMESPOT</a></li>
							<li><a href="http://www.gamefaqs.com">GameFAQs</a></li>
						</ul>
						</div>
					</td>
					<td>
					<div id="last_list2">
						<h2  style="color: white">STORE :</h2>
						<ul>
							<li><a href="https://store.playstation.com/#!/en-us/home/games">PSN</a></li>
							<li><a href="http://www.xbox.com/en-US/live">XBOX LIVE</a></li>
							<li><a href="https://www.amazon.com/">AMAZON</a></li>
							<li><a href="http://store.steampowered.com/">STEAM</a></li>
							</div>
						</ul>
					</td>
					<td>
						<h2  style="color: white">BEST SELLING CONSOLES :</h2>
						<ul>
							<li>PS4(399$)</li>
							<li>XBOX ONE(399$)</a></li>
							<li>3DS(99$)</li>
							<li>PS3(199$)</li>
							<li>XBOX 360(199$)</li>
							<li>WII U(199$)</li>
						</ul>
					</td>
					<td>
					<div id="last_list4">
						<h2  style="color: white">Communities :</h2>
						<ul>
							<li><a href="http://www.facebook.com/">Facebook</a></li>
							<li><a href="http://www.twitter.com">Twitter</a></li>
							<li><a href="http://www.youtube.com">Youtube</a></li>
						</ul>
						</div>
					</td>
					<td>
					<div id="last_list5">
						<h2  style="color: white">NEWS </h2>
					<ul>
						<li><a href="pc.php">PC</a></li>
						<li>PS4</li>
						<li>Xbox One</li>
						<li>Wii U</li>
						</ul>
						</div>
					</td>
				</tr>
				<tr>
					<th colspan="5"><h1  style="color: white">..... GameGEN .....</h1></th>
				</tr>
		   </table>
		   </div>

        <!_________________ LAST DIV____________________>
		</div>
	</body>
</html>