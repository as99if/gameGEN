<?php
	include ('head.php');
?>
	
            <!_____after menu__>
		 <div id="bla"><br/><br/><br/></div>
		<div id="ta">     <!____- ei div bad, cover pic hobe >
            <table id="ppc" cellspacing="2" width="100%" background="g.jpg">
            	<tr>
            		<td rowspan="2" width="20%">
            		</td>
            		<td rowspan="2" width="40%" background="un1.jpg">
               		<div id="r"><a href="rev.php">
            			<hgroup>
            			<h1  style="color: white">Uncharted 4 Game of The Year</h1>
            			<br>
      	   			    <h2  style="color: white">Uncharted 4: A Thief's End is an action-adventure video game
      	   			    developed by Naughty Dog and published by Sony Interactive
      	   			    </h2>
      	   				</hgroup>
            		</a></div>
            		</td>
            		<td width="20%" background="un1.jpg">
            		<br/>
      				<div id="r"><a href="rev.php">
            			<hgroup>
            			<h2  style="color: white">Uncharted 4 Game of The Year</h2>
            			<p  style="color: white">this games review in progress</p>
            			<br/>
      	   				</hgroup>
            		</a></div>
            		</td>
            		<td width="20%">
            		</td>
            	</tr>
            	<tr>
            		<td width="20%" background="un1.jpg">
            		<br/>
            		<div id="r"><a href="rev.php">
            			<hgroup>
            			<h2  style="color: white">Uncharted 4 Game of The Year</h2>
            			<p  style="color: white">this games review in progress</p>
            			<br/>
      	   				</hgroup>
            		</a></div>
            		</td>
            	</tr>
            </table>
            </div> 
              <table cellspacing="5" width="100%">
              <tr>
			  <td width="30%">
					<img  src="un1.jpg" width="100%"/>
				</td>
              <td width="50%">
                        <h1 id="h">Game of The Year 2016</h1>
                        <p id="un">Uncharted 4: A Thief's End is an action-adventure video game developed by Naughty Dog and published by Sony Interactive Entertainment for the PlayStation 4 video game console.</p>
			</td>
          <?php
            $result = $db->query("SELECT title, year FROM game_main
                                  WHERE year>= 2016");

            
          ?>  
          
            <td rowspan="2" width="20%">
                <div id="up_list">    <!__ete query hobe__>
                <h2>TOP RATED GAMES</h2>
                <br/>

                <dl id="up_games">
                <!__pc top rated query____>
                <dl id="up_games">
                <?php
                  $pc_top_rated = $db->query("SELECT id, title, rating
                                        FROM rating_on_console
                                          WHERE console= 'pc'
                                          ORDER BY rating DESC
                                          LIMIT 5 ");
                  $row = $pc_top_rated->fetch_assoc();
                  while($row!=NULL){
                    echo"
                      <li><a href='rev.php?game_id=$row[id]'>$row[title]</a><br>
                       
                      </li><br>
                    ";
                    $row = $pc_top_rated->fetch_assoc();
                  }
                ?>
                </dl>
                <!__pc top rated query__shesh>
                </dl>
            </div>
                </td>
                </tr>
				<tr>
				<td width="30%">
					<img  src="un1.jpg" width="100%"/>
				</td>
				<td width="50%">
                        <h1 id="h">Game of The Year 2016</h1>
                        <p id="un">Uncharted 4: A Thief's End is an action-adventure video game developed by Naughty Dog and published by Sony Interactive Entertainment for the PlayStation 4 video game console.</p>
            </td>
				</tr>
				<!________________>
				<tr>
				<td width="30%">
					<img  src="un1.jpg" width="100%"/>
				</td>
				<td width="50%">
                        <h1 id="h">Game of The Year 2016</h1>
                        <p id="un">Uncharted 4: A Thief's End is an action-adventure video game developed by Naughty Dog and published by Sony Interactive Entertainment for the PlayStation 4 video game console.</p>
            </td>
			<td>
				 <div id="reviews_list">  <!__ete query hobe__>
            <h2>&nbsp;&nbsp;EXPLORE GAMES BY </h2>
                <table width="95%" cellspacing="10">
                   <tr>
						<td>
						<h2>Coming Soon</h2>
						<br/>
							<ul id="coming">
								<!_______pc coming soon query________>
              <?php
              $pc_coming_soon = $db->query("SELECT title, id
                                          FROM game_main
                                          WHERE year > YEAR(CURDATE()) AND id IN (
                                                SELECT id FROM game_console
                                                WHERE console = 'pc'
                                              )
                                          ORDER BY year DESC
                                          LIMIT 5 ");
                        $row = $pc_coming_soon->fetch_assoc();
            
              while($row != NULL){
                echo "
                <li>$row[title]</li>
              ";
              $row = $pc_coming_soon->fetch_assoc();
              }
              ?>
              <!_______pc coming soon query shesh________>

							</ul>
						</td>
				
						<td>
						<h2>Latest Releases</h2>
						<br/>
							<ul id="coming">
								<!_____________pc latest query_____________>
              <?php
              $pc_latest = $db->query("SELECT title, id
                        FROM game_main
                        WHERE year <= YEAR(CURDATE()) AND id IN (
                          SELECT id FROM game_console
                          WHERE console = 'pc'
                        )
                                          ORDER BY year DESC
                                          LIMIT 5 ");
                        $row = $pc_latest->fetch_assoc();
            
              while($row != NULL){
                echo "
                <li>$row[title]</li>
              ";
              $row = $pc_latest->fetch_assoc();
              }
              ?>
              <!_____________pc latest query shesh_____________>
							</ul>
						</td>
                   </tr>
                </table>
 
            </div>   
			</td>
				</tr>
				<!________________>
				<tr>
				<td width="30%">
					<img  src="un1.jpg" width="100%"/>
				</td>
				<td width="50%">
                        <h1 id="h">Game of The Year 2016</h1>
                        <p id="un">Uncharted 4: A Thief's End is an action-adventure video game developed by Naughty Dog and published by Sony Interactive Entertainment for the PlayStation 4 video game console.</p>
            </td>
			<td>
				 <div id="reviews_list">  <!__ete query hobe__>
            <h2>&nbsp;&nbsp;EXPLORE GAMES BY </h2>
                <table width="95%" cellspacing="10">
                   <tr>
						<td>
						<h2>Genre</h2>
						<br/>
							<ul id="genre">        <!____query___>
								<li>Action</li>
								<li>Adventure</li>
								<li>Driving</li>
								<li>Shooter</li>
								<li>MMO</li>
								<li>Sports</li>
								<li>FPS</li>
							</ul>
						</td>
                   </tr>
				   <tr>
						<td>
						<h2>Theme</h2>
						<br/>
							<ul id="genre">      <!____query___>
								<li>Crime</li>
								<li>Sci-fi</li>
								<li>Space</li>
								<li>Horror</li>
								<li>Military</li>
							</ul>
						</td>
                   </tr>
                </table>
 
            </div>   
			</td>
				</tr>
              </table>
            <!_____________________>
<?php
	include ('foot.php');
?>

